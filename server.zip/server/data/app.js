    document.addEventListener('DOMContentLoaded', () => {
        document.getElementById('sendData').addEventListener('click', () => {
            console.log('in');
            let sec = 8;
            let days = 5;
            let cls = 6;
              const teacher = [
            'Alice', 'Bob', 'Charlie', 'David', 'Eva',
            'Frank', 'Grace', 'Hannah', 'Ivan', 'Julia'
        ];

            fetch('http://localhost:3000/data', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => {
                console.log('Response received:', response);
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Success:', data); // Log the entire response data

                const routineOutput = document.getElementById('routineOutput');
                routineOutput.innerHTML = '<h2>Routine</h2>';
                for (let i = 0; i < sec; i++) {
                    routineOutput.innerHTML += `<h3>Section ${i + 1}</h3>`;
                    const table = document.createElement('table');
                    const thead = document.createElement('thead');
                    const tbody = document.createElement('tbody');
                    const headRow = document.createElement('tr');
                    for (let j = 0; j < cls; j++) {
                        const th = document.createElement('th');
                        th.textContent = `Period ${j + 1}`;
                        headRow.appendChild(th);
                    }
                    thead.appendChild(headRow);
                
                    for (let j = 0; j < days; j++) {
                        const tr = document.createElement('tr');
                        for (let k = 0; k < cls; k++) {
                            const td = document.createElement('td');
                            td.textContent = teacher[data[i][j][k]]; 
                            tr.appendChild(td);
                        }
                        tbody.appendChild(tr);
                    }
                    table.appendChild(thead);
                    table.appendChild(tbody);
                    routineOutput.appendChild(table);
                }
            })
            .catch((error) => {
                console.error('Error:', error);
            });
        });
    });
