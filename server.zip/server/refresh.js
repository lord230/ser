// public/refresh.js
setTimeout(function(){
    location.reload();
 }, 5000); // 5000 milliseconds = 5 seconds
 